using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using SampleSecureWeb.Data;
using SampleSecureWeb.Models;
using SampleSecuredWeb.ViewModels; 

namespace SampleSecuredWeb.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUser _userData;

        public AccountController(IUser user)
        {
            _userData = user;
        }  

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegistrationViewModel registrationViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var password = registrationViewModel.Password ?? string.Empty;

                    if (password.Length < 12 || password.Length > 128 ||
                        !password.Any(char.IsUpper) ||
                        !password.Any(char.IsLower) ||
                        !password.Any(char.IsDigit))
                    {
                        ModelState.AddModelError("Password", "Password harus antara 12 hingga 128 karakter, memiliki huruf besar, huruf kecil, dan angka.");
                        return View(registrationViewModel);
                    }

                    // Hashing password sebelum disimpan (opsional)
                    var hashedPassword = password; // Ganti hashing dihapus jika tidak digunakan

                    var user = new User
                    {
                        Username = registrationViewModel.Username ?? string.Empty,
                        Password = hashedPassword,
                        RoleName = "contributor"
                    };

                    _userData.Registration(user);
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }
            return View(registrationViewModel);
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel loginViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var password = loginViewModel.Password ?? string.Empty;

                    var user = new User
                    {
                        Username = loginViewModel.Username,
                        Password = password
                    };

                    var loginUser = _userData.Login(user);
                    if (loginUser == null || loginUser.Password != password) // Ganti verifikasi hashing dihapus
                    {
                        ViewBag.Message = "Invalid login attempt.";
                        return View(loginViewModel);
                    }

                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, loginUser.Username)
                    };
                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);

                    await HttpContext.SignInAsync(
                        CookieAuthenticationDefaults.AuthenticationScheme,
                        principal,
                        new AuthenticationProperties
                        {
                            IsPersistent = loginViewModel.RememberLogin
                        });
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View(loginViewModel);
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ChangePassword(ChangePasswordViewModel changePasswordViewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(changePasswordViewModel);
            }

            try
            {
                var newPassword = changePasswordViewModel.NewPassword ?? string.Empty;
                if (newPassword.Length < 12 || newPassword.Length > 128 ||
                    !newPassword.Any(char.IsUpper) ||
                    !newPassword.Any(char.IsLower) ||
                    !newPassword.Any(char.IsDigit))
                {
                    ModelState.AddModelError("NewPassword", "Password baru harus antara 12 hingga 128 karakter, memiliki huruf besar, huruf kecil, dan angka.");
                    return View(changePasswordViewModel);
                }

                var username = User.Identity?.Name;
                if (string.IsNullOrEmpty(username))
                {
                    ModelState.AddModelError(string.Empty, "User tidak ditemukan. Silakan login kembali.");
                    return View(changePasswordViewModel);
                }

                var currentUser = _userData.GetCurrentUser(username);
                if (currentUser == null)
                {
                    ModelState.AddModelError(string.Empty, "User tidak ditemukan.");
                    return View(changePasswordViewModel);
                }

                // Perbarui password di database
                currentUser.Password = newPassword; // Simpan password baru

                _userData.UpdatePassword(currentUser);

                ViewBag.Message = "Password berhasil diubah!";
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Terjadi kesalahan: {ex.Message}");
            }

            return View(changePasswordViewModel);
        }
    }
}
